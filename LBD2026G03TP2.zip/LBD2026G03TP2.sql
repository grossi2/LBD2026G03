use LBD2026G03Farmacia;
SELECT * FROM Compras;
SELECT * FROM LineaCompras;
SELECT * FROM LineaVentas;
SELECT * FROM Ventas;
SELECT * FROM Usuarios;
SELECT * FROM Productos;
SELECT * FROM Monodrogas;
SELECT * FROM ProductoMonodrogas;



-- CONSULTA 1
-- Datos de una venta entre dos fechas (en este caso entre 01/5 y 0/12 sin incluirlo al segundo )
SELECT v.IdVenta, v.FechaVenta, u.Nombre, u.Apellido, l.IdProducto, l.Cantidad,(l.Cantidad*l.PrecioUnitario) as "Subtotal" FROM Ventas v
INNER JOIN Usuarios u ON v.IdUsuario = u.IdUsuario
INNER JOIN LineaVentas l ON l.IdVenta=v.IdVenta
WHERE v.FechaVenta between "2026-01-04" AND "2026-01-12";

-- CONSULTA 2
-- Listar los producto más vendidos y cantidad vendida que tengan una determinada monodroga
-- Monodrogas con más de 5 productos: Paracetamol o Ibuprofeno

SELECT p.Nombre as "Producto", SUM(lv.Cantidad) as "Cantidad vendida"
FROM Productos p
INNER JOIN ProductoMonodrogas pm ON p.IdProducto = pm.IdProducto
INNER JOIN Monodrogas m ON m.IdMonodroga = pm.IdMonodroga
INNER JOIN LineaVentas lv ON p.IdProducto = lv.IdProducto
INNER JOIN Ventas v ON v.IdVenta = lv.IdVenta
WHERE m.Nombre LIKE 'Paracetamol' AND v.FechaVenta between "2026-01-04" AND "2026-10-04"
GROUP BY p.Nombre, m.Nombre
ORDER BY SUM(lv.Cantidad) DESC
LIMIT 5;

-- CONSULTA 3
-- Todos los producto indicando su stock y nombre. 
-- Hay productos con cantidad cero (Diclofenac y Claritromicina) 

SELECT T.Nombre as "Producto" , SUM(Coalesce(stock,0)) as "stock" FROM 
(
SELECT p.Nombre, coalesce(-lv.Cantidad,0) as "stock" FROM Productos p
INNER join LineaVentas lv ON lv.IdProducto = p.IdProducto

UNION

SELECT p.Nombre, coalesce(lc.Cantidad,0) as "stock" FROM Productos p
left JOIN LineaCompras lc ON lc.IdProducto = p.IdProducto
) AS T
GROUP BY T.Nombre
ORDER BY T.Nombre asc;

-- CONSULTA 4: Ro
-- Total de ventas y monto recaudado por tipo de producto en un mes especifico.
SELECT IF(p.RequiereReceta = 'S', 'Requiere Receta', 'Venta Libre') as "Tipo de producto",
COUNT(*) as "Total ventas",
SUM(lv.Cantidad * lv.PrecioUnitario) as "Monto total"
FROM Ventas v
INNER JOIN LineaVentas lv ON lv.IdVenta = v.IdVenta
INNER JOIN Productos p ON p.IdProducto = lv.IdProducto
WHERE YEAR(v.FechaVenta) = 2026 AND MONTH(v.FechaVenta) = 1
GROUP BY p.RequiereReceta;

-- CONSULTA 5: R
-- Ranking de proveedores segun la cantidad total de unidades compradas en el ultimo anio.
SELECT p.Nombre as "Proveedor", SUM(lc.Cantidad) as "Total unidades"
FROM Proveedores p
INNER JOIN Compras c ON c.IdProveedor = p.IdProveedor
INNER JOIN LineaCompras lc ON lc.IdCompra = c.IdCompra AND lc.IdProveedor = c.IdProveedor AND lc.IdUsuario = c.IdUsuario
WHERE YEAR(c.FechaCompra) = 2026
GROUP BY p.IdProveedor, p.Nombre
ORDER BY SUM(lc.Cantidad) DESC;

-- CONSULTA 6: R
-- Total de compras y ventas por mes de 2026. En el script hay datos cargados para todos los meses.
SELECT c.Mes, c.TotalCompras, v.TotalVentas
FROM (
SELECT MONTH(c.FechaCompra) as Mes, SUM(lc.Cantidad * lc.PrecioCompraUnitario) as TotalCompras
FROM Compras c
INNER JOIN LineaCompras lc ON lc.IdCompra = c.IdCompra AND lc.IdProveedor = c.IdProveedor AND lc.IdUsuario = c.IdUsuario
WHERE YEAR(c.FechaCompra) = 2026
GROUP BY MONTH(c.FechaCompra)
) c
INNER JOIN (
SELECT MONTH(v.FechaVenta) as Mes, SUM(lv.Cantidad * lv.PrecioUnitario) as TotalVentas
FROM Ventas v
INNER JOIN LineaVentas lv ON lv.IdVenta = v.IdVenta
WHERE YEAR(v.FechaVenta) = 2026
GROUP BY MONTH(v.FechaVenta)
) v ON c.Mes = v.Mes
ORDER BY c.Mes;

-- CONSULTA 7: C
-- Total de las ventas de los empleados, hay emppleados que no realizaron ventas

SELECT concat(u.Nombre," ", u.Apellido) as "Empleado" ,SUM(coalesce(lv.Cantidad * lv.PrecioUnitario, 0)) as "Total Ventas"
FROM Usuarios u
LEFT JOIN LineaVentas lv ON lv.IdUsuario = u.IdUsuario
WHERE u.Puesto = "EMPLEADO"
GROUP BY u.IdUsuario
ORDER BY SUM(coalesce(lv.Cantidad * lv.PrecioUnitario, 0)) DESC;

-- CONSULTA 8: C
-- vista con la funcionalidad de uno para compras (Datos de las compras por cada empleado)

DROP VIEW IF exists vw_DetalleCompras;
CREATE VIEW  vw_DetalleCompras (Proveedor, Usuario, Producto, Lotes, FechaVencimiento) AS
	SELECT pr.Nombre, u.NombreUsuario, p.Nombre, l.Lote, l.FechaVencimiento 
	FROM Compras c
    INNER JOIN Usuarios u ON c.IdUsuario = u.IdUsuario
    INNER JOIN LineaCompras l ON l.IdCompra = c.IdCompra
    INNER JOIN Productos p ON l.IdProducto = p.IdProducto
    INNER JOIN Proveedores pr ON  pr.IdProveedor = l.IdProveedor
	WHERE c.FechaCompra BETWEEN '2026-03-04' AND '2026-6-12';
select * from vw_DetalleCompras;

-- CONSULTA 9: 
-- Tabla Productos_Historico con columna JSON
DROP TABLE IF EXISTS Productos_Historico;
CREATE TABLE IF NOT EXISTS `Productos_Historico` (
    `IdProducto` INT NOT NULL AUTO_INCREMENT,
    `Nombre` VARCHAR(100) NOT NULL,
    `CodigoProducto` VARCHAR(20) NOT NULL,
    `CodigoBarra` VARCHAR(20) NULL,
    `PrecioBase` DECIMAL(10, 2) NOT NULL,
    `RequiereReceta` CHAR(1) NOT NULL DEFAULT 'N',
    `StockMinimo` INT NOT NULL DEFAULT 0,
    `Estado` CHAR(1) NOT NULL DEFAULT 'A',
	`Lotes`JSON NULL,
    PRIMARY KEY (`IdProducto`),
    CONSTRAINT `UkProductosHistoricoCodigoProducto` UNIQUE (`CodigoProducto`),
    CONSTRAINT `UkProductosHistoricoCodigoBarra` UNIQUE (`CodigoBarra`),
    CONSTRAINT `ChkProductosHistoricoPrecioBase` CHECK (`PrecioBase` > 0),
    CONSTRAINT `ChkProductosHistoricoRequiereReceta` CHECK (
        `RequiereReceta` IN ('S', 'N')
    ),
    CONSTRAINT `ChkProductosHistoricoStockMinimo` CHECK (`StockMinimo` >= 0),
    CONSTRAINT `ChkProductosHistoricoEstado` CHECK (`Estado` IN ('A', 'I'))
) ENGINE = InnoDB;
CREATE INDEX `IxProductosHistoricoNombre` ON `Productos_Historico` (`Nombre`);

CREATE INDEX `IxProductosHistoricoStockMinimo` ON `Productos_Historico` (`StockMinimo`);

-- Insertar los datos previos de Productos en Productos_Historicos y mostrar la tabla resultante para verificar

INSERT INTO Productos_Historico (IdProducto, Nombre, CodigoProducto, CodigoBarra, PrecioBase, RequiereReceta, StockMinimo, Estado, Lotes)
	select p.IdProducto, p.Nombre, p.CodigoProducto, p.CodigoBarra, p.PrecioBase, p.RequiereReceta, p.StockMinimo, p.Estado, 
		JSON_ARRAYAGG(
							if( lc.lote is null,null,
								JSON_OBJECT("Lote",lc.lote,"FechaVencimiento",lc.FechaVencimiento)
								)
							) 
					as "lotes"
	FROM Productos p
	left JOIN LineaCompras lc ON p.IdProducto = lc.IdProducto
    group by p.IdProducto;
    
    select * from Productos_Historico;

-- Mostrar los lotes y fechas de vencimiento del producto con IdProducto=5

select Lote, FechaVencimiento as "Fecha Vencimiento" from Productos_Historico ph, JSON_TABLE(Lotes,'$[*]' 
	COLUMNS(
		Lote VARCHAR(10) PATH '$.Lote',
		FechaVencimiento VARCHAR(10) PATH '$.FechaVencimiento'
	)
) AS TablaJSON
where ph.IdProducto=5
order by FechaVencimiento;	

-- Método alternativo de almacenar los lotes

select p.IdProducto, coalesce(("Lote",JSON_ARRAYAGG(lc.lote),"fv", JSON_ARRAYAGG(lc.FechaVencimiento))) as "lotes" FROM Productos p
INNER JOIN LineaCompras lc ON p.IdProducto = lc.IdProducto
where p.IdProducto = 21
group by p.IdProducto;

-- CONSULTA 10
-- Listar los nombres de los 5 productos mas cercanos a vencer que no se vendieron, junto a sus lotes, fecha de vencimiento y el stock de ellos

select min(p.IdProducto), min(p.Nombre) as "Producto", T.Lote, Min(T.FechaVencimiento) as "Fecha de Vencimiento", SUM(coalesce(T.Cantidad,0)) as "stock" from 
(
select lc.IdProducto, lc.Lote, lc.FechaVencimiento,lc.Cantidad from LineaCompras lc
union
select lv.IdProducto, lv.Lote, lv.FechaVencimiento,-lv.Cantidad from LineaVentas lv
) as T
left join Productos p
on p.IdProducto=T.IdProducto
Group by T.Lote
having stock>0
order by Min(T.FechaVencimiento) asc
Limit 5;