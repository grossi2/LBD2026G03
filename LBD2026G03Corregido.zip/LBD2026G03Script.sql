-- Ano: 2026
-- Grupo Nro: 03
-- Integrantes: Singh Neelam Rocio del Milagro, Villanueva Giribaldi Camilo
-- Tema: Sistema de Gestion para Farmacia
-- Nombre del Esquema: LBD2026G03Farmacia
-- Plataforma (SO + Version): Windows
-- Motor y Version: MySQL Server 8.0
-- GitHub Repositorio: LBD2026G03
-- GitHub Usuarios: RooSingh, VillanuevaGiribaldi

SET @OldUniqueChecks = @@UNIQUE_CHECKS;

SET UNIQUE_CHECKS = 0;

SET @OldForeignKeyChecks = @@FOREIGN_KEY_CHECKS;

SET FOREIGN_KEY_CHECKS = 0;

SET @OldSqlMode = @@SQL_MODE;

SET
    SQL_MODE = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

DROP DATABASE IF EXISTS `LBD2026G03Farmacia`;

CREATE SCHEMA IF NOT EXISTS `LBD2026G03Farmacia` DEFAULT CHARACTER SET utf8mb4;

USE `LBD2026G03Farmacia`;

CREATE TABLE IF NOT EXISTS `Usuarios` (
    `IdUsuario` INT NOT NULL AUTO_INCREMENT,
    `Nombre` VARCHAR(45) NOT NULL,
    `Apellido` VARCHAR(45) NOT NULL,
    `NombreUsuario` VARCHAR(45) NOT NULL,
    `Dni` VARCHAR(9) NOT NULL,
    `Sexo` CHAR(1) NOT NULL,
    `Edad` TINYINT UNSIGNED NOT NULL,
    `Direccion` VARCHAR(120) NOT NULL,
    `Telefono` VARCHAR(20) NOT NULL,
    `Mail` VARCHAR(100) NOT NULL,
    `EstadoCivil` VARCHAR(20) NOT NULL,
    `Puesto` ENUM('GERENTE', 'EMPLEADO') NOT NULL DEFAULT 'EMPLEADO',
    `AntiguedadAnios` TINYINT UNSIGNED NOT NULL DEFAULT 0,
    `Estado` CHAR(1) NOT NULL DEFAULT 'A',
    `Contrasena` VARCHAR(60) NOT NULL,
    PRIMARY KEY (`IdUsuario`),
    CONSTRAINT `UkUsuariosNombreUsuario` UNIQUE (`NombreUsuario`),
    CONSTRAINT `UkUsuariosDni` UNIQUE (`Dni`),
    CONSTRAINT `UkUsuariosMail` UNIQUE (`Mail`),
    CONSTRAINT `ChkUsuariosSexo` CHECK (`Sexo` IN ('F', 'M', 'X')),
    CONSTRAINT `ChkUsuariosEdad` CHECK (`Edad` BETWEEN 18 AND 99),
    CONSTRAINT `ChkUsuariosEstado` CHECK (`Estado` IN ('A', 'I')),
    CONSTRAINT `ChkUsuariosAntiguedad` CHECK (`AntiguedadAnios` >= 0)
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `Proveedores` (
    `IdProveedor` INT NOT NULL AUTO_INCREMENT,
    `Nombre` VARCHAR(80) NOT NULL,
    `Telefono` VARCHAR(20) NOT NULL,
    `Mail` VARCHAR(100) NOT NULL,
    `Direccion` VARCHAR(120) NOT NULL,
    `Estado` CHAR(1) NOT NULL DEFAULT 'A',
    PRIMARY KEY (`IdProveedor`),
    CONSTRAINT `UkProveedoresNombre` UNIQUE (`Nombre`),
    CONSTRAINT `UkProveedoresMail` UNIQUE (`Mail`),
    CONSTRAINT `ChkProveedoresEstado` CHECK (`Estado` IN ('A', 'I'))
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `Monodrogas` (
    `IdMonodroga` INT NOT NULL AUTO_INCREMENT,
    `Nombre` VARCHAR(60) NOT NULL,
    `Estado` CHAR(1) NOT NULL DEFAULT 'A',
    PRIMARY KEY (`IdMonodroga`),
    CONSTRAINT `UkMonodrogasNombre` UNIQUE (`Nombre`),
    CONSTRAINT `ChkMonodrogasEstado` CHECK (`Estado` IN ('A', 'I'))
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `Productos` (
    `IdProducto` INT NOT NULL AUTO_INCREMENT,
    `Nombre` VARCHAR(100) NOT NULL,
    `CodigoProducto` VARCHAR(20) NOT NULL,
    `CodigoBarra` VARCHAR(20) NULL,
    `PrecioBase` DECIMAL(10, 2) NOT NULL,
    `RequiereReceta` CHAR(1) NOT NULL DEFAULT 'N',
    `StockMinimo` INT NOT NULL DEFAULT 0,
    `Estado` CHAR(1) NOT NULL DEFAULT 'A',
    PRIMARY KEY (`IdProducto`),
    CONSTRAINT `UkProductosCodigoProducto` UNIQUE (`CodigoProducto`),
    CONSTRAINT `UkProductosCodigoBarra` UNIQUE (`CodigoBarra`),
    CONSTRAINT `ChkProductosPrecioBase` CHECK (`PrecioBase` > 0),
    CONSTRAINT `ChkProductosRequiereReceta` CHECK (
        `RequiereReceta` IN ('S', 'N')
    ),
    CONSTRAINT `ChkProductosStockMinimo` CHECK (`StockMinimo` >= 0),
    CONSTRAINT `ChkProductosEstado` CHECK (`Estado` IN ('A', 'I'))
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `ProductoMonodrogas` (
    `IdProducto` INT NOT NULL,
    `IdMonodroga` INT NOT NULL,
    PRIMARY KEY (`IdProducto`, `IdMonodroga`),
    CONSTRAINT `FkProductoMonodrogasProducto` FOREIGN KEY (`IdProducto`) REFERENCES `Productos` (`IdProducto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FkProductoMonodrogasMonodroga` FOREIGN KEY (`IdMonodroga`) REFERENCES `Monodrogas` (`IdMonodroga`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `ProveedorProductos` (
    `IdProveedor` INT NOT NULL,
    `IdProducto` INT NOT NULL,
    PRIMARY KEY (`IdProveedor`, `IdProducto`),
    CONSTRAINT `FkProveedorProductosProveedor` FOREIGN KEY (`IdProveedor`) REFERENCES `Proveedores` (`IdProveedor`) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FkProveedorProductosProducto` FOREIGN KEY (`IdProducto`) REFERENCES `Productos` (`IdProducto`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `Ventas` (
    `IdVenta` INT NOT NULL AUTO_INCREMENT,
    `IdUsuario` INT NOT NULL,
    `FechaVenta` DATETIME NULL DEFAULT NULL,
    `Estado` CHAR(1) NOT NULL DEFAULT 'A',
    PRIMARY KEY (`IdVenta`, `IdUsuario`),
    INDEX `ixVentasUsuarios` (`IdUsuario` ASC) VISIBLE,
    CONSTRAINT `FkVentasUsuarios`
        FOREIGN KEY (`IdUsuario`)
        REFERENCES `Usuarios` (`IdUsuario`),
    CONSTRAINT `ChkVentasEstado` CHECK (`Estado` IN ('A', 'I'))
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `LineaVentas` (
    `IdLineaVenta` INT NOT NULL AUTO_INCREMENT,
  `IdUsuario` INT NOT NULL,
  `IdVenta` INT NOT NULL,
  `IdProducto` INT NOT NULL,
  `Cantidad` INT NOT NULL DEFAULT '1',
  `FechaVencimiento` DATE NULL DEFAULT NULL,
  `Lote` VARCHAR(10) NULL DEFAULT NULL,
  `FechaTransaccion` DATETIME NULL DEFAULT NULL,
  `PrecioUnitario` DECIMAL(10,2) NULL DEFAULT NULL,
  PRIMARY KEY (`IdLineaVenta`, `IdVenta`, `IdProducto`, `IdUsuario`),
  INDEX `ixLineaVentasVentas` (`IdVenta` ASC, `IdUsuario` ASC) VISIBLE,
  INDEX `ixLineaVentasProductos` (`IdProducto` ASC) VISIBLE,
  CONSTRAINT `FkLineaVentasProductos`
    FOREIGN KEY (`IdProducto`)
    REFERENCES `Productos` (`IdProducto`),
  CONSTRAINT `FkLineaVentasVentas`
    FOREIGN KEY (`IdVenta` , `IdUsuario`)
    REFERENCES `Ventas` (`IdVenta` , `IdUsuario`),    
    CONSTRAINT `ChkLineaVentasCantidad` CHECK (`Cantidad` > 0),
    CONSTRAINT `ChkLineaVentasPrecioUnitario` CHECK (`PrecioUnitario` > 0)
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `Compras` (
  `IdCompra` INT NOT NULL AUTO_INCREMENT,
  `IdUsuario` INT NOT NULL,
  `IdProveedor` INT NOT NULL,
  `FechaCompra` DATETIME NULL DEFAULT NULL,
  `Estado` VARCHAR(45) NOT NULL DEFAULT 'A',
  PRIMARY KEY (`IdCompra`, `IdUsuario`, `IdProveedor`),
  INDEX `ixComprasProveedores` (`IdProveedor` ASC) VISIBLE,
  INDEX `ixComprasUsuarios` (`IdUsuario` ASC) VISIBLE,
  CONSTRAINT `FkComprasProveedores`
    FOREIGN KEY (`IdProveedor`)
    REFERENCES `Proveedores` (`IdProveedor`),
  CONSTRAINT `FkComprasUsuarios`
    FOREIGN KEY (`IdUsuario`)
    REFERENCES `Usuarios` (`IdUsuario`),
    CONSTRAINT `ChkComprasEstado` CHECK (`Estado` IN ('A', 'I'))
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `LineaCompras` (
    
    `IdLineaCompra` INT NOT NULL AUTO_INCREMENT,
    `IdCompra` INT NOT NULL,
    `IdProducto` INT NOT NULL,    
    `IdUsuario` INT NOT NULL,
    `IdProveedor` INT NOT NULL,
    `PrecioCompraUnitario` DECIMAL(10, 2) NOT NULL,
    `FechaTransaccion` DATETIME NOT NULL,
    `FechaVencimiento` DATE NULL,
    `Lote` VARCHAR(20) NULL,
    `Cantidad` INT NOT NULL DEFAULT 1,
    PRIMARY KEY (`IdLineaCompra`, `IdCompra`, `IdProducto`, `IdUsuario`, `IdProveedor`),
    INDEX `ixLineaComprasCompras` (`IdCompra` ASC, `IdUsuario` ASC, `IdProveedor` ASC) VISIBLE,
    INDEX `ixLineaComprasProductos` (`IdProducto` ASC) VISIBLE,
    CONSTRAINT `FkLineaComprasCompras`
        FOREIGN KEY (`IdCompra` , `IdUsuario` , `IdProveedor`)
        REFERENCES `Compras` (`IdCompra` , `IdUsuario` , `IdProveedor`),
    CONSTRAINT `FkLineaComprasProductos`
        FOREIGN KEY (`IdProducto`)
        REFERENCES `Productos` (`IdProducto`),
    CONSTRAINT `ChkLineaComprasPrecioCompraUnitario` CHECK (`PrecioCompraUnitario` > 0),
    CONSTRAINT `ChkLineaComprasCantidad` CHECK (`Cantidad` > 0)
) ENGINE = InnoDB;

SET SQL_MODE = @OldSqlMode;

SET FOREIGN_KEY_CHECKS = @OldForeignKeyChecks;

SET UNIQUE_CHECKS = @OldUniqueChecks;

CREATE INDEX `IxUsuariosApellidoNombre` ON `Usuarios` (`Apellido`, `Nombre`);

CREATE INDEX `IxUsuariosPuestoEstado` ON `Usuarios` (`Puesto`, `Estado`);

CREATE INDEX `IxProductosNombre` ON `Productos` (`Nombre`);

CREATE INDEX `IxProductosStockMinimo` ON `Productos` (`StockMinimo`);

CREATE INDEX `IxProveedoresEstadoNombre` ON `Proveedores` (`Estado`, `Nombre`);

CREATE INDEX `IxVentasFechaVenta` ON `Ventas` (`FechaVenta`);

CREATE INDEX `IxComprasFechaCompra` ON `Compras` (`FechaCompra`);

CREATE INDEX `IxLineaVentasLote` ON `LineaVentas` (`Lote`);

CREATE INDEX `IxLineaComprasLote` ON `LineaCompras` (`Lote`);

CREATE INDEX `IxProductoMonodrogasIdMonodroga` ON `ProductoMonodrogas` (`IdMonodroga`);

CREATE INDEX `IxProveedorProductosIdProducto` ON `ProveedorProductos` (`IdProducto`);

INSERT INTO
    `Usuarios` (
        `Nombre`,
        `Apellido`,
        `NombreUsuario`,
        `Dni`,
        `Sexo`,
        `Edad`,
        `Direccion`,
        `Telefono`,
        `Mail`,
        `EstadoCivil`,
        `Puesto`,
        `AntiguedadAnios`,
        `Estado`,
        `Contrasena`
    )
VALUES (
        'Juan',
        'Perez',
        'jperez',
        '30111222',
        'M',
        45,
        'San Martin 123',
        '3815551101',
        'juan.perez@farmaciasanrafael.com.ar',
        'CASADO',
        'GERENTE',
        12,
        'A',
        '123'
    ),
    (
        'Ana',
        'Gomez',
        'agomez',
        '30222333',
        'F',
        38,
        'Belgrano 456',
        '3815551102',
        'ana.gomez@farmaciasanrafael.com.ar',
        'CASADO',
        'GERENTE',
        9,
        'A',
        '123'
    ),
    (
        'Luis',
        'Martinez',
        'lmartinez',
        '30333444',
        'M',
        29,
        'Mendoza 789',
        '3815551103',
        'luis.martinez@farmaciasanrafael.com.ar',
        'SOLTERO',
        'EMPLEADO',
        3,
        'A',
        '123'
    ),
    (
        'Carla',
        'Lopez',
        'clopez',
        '30444555',
        'F',
        31,
        'Roca 147',
        '3815551104',
        'carla.lopez@farmaciasanrafael.com.ar',
        'SOLTERO',
        'EMPLEADO',
        4,
        'A',
        '123'
    ),
    (
        'Diego',
        'Sosa',
        'dsosa',
        '30555666',
        'M',
        27,
        'Mitre 258',
        '3815551105',
        'diego.sosa@farmaciasanrafael.com.ar',
        'SOLTERO',
        'EMPLEADO',
        2,
        'A',
        '123'
    ),
    (
        'Maria',
        'Diaz',
        'mdiaz',
        '30666777',
        'F',
        34,
        'Laprida 369',
        '3815551106',
        'maria.diaz@farmaciasanrafael.com.ar',
        'CASADO',
        'EMPLEADO',
        5,
        'A',
        '123'
    ),
    (
        'Pablo',
        'Suarez',
        'psuarez',
        '30777888',
        'M',
        40,
        'Congreso 741',
        '3815551107',
        'pablo.suarez@farmaciasanrafael.com.ar',
        'CASADO',
        'EMPLEADO',
        8,
        'A',
        '123'
    ),
    (
        'Lucia',
        'Torres',
        'ltorres',
        '30888999',
        'F',
        26,
        'Italia 852',
        '3815551108',
        'lucia.torres@farmaciasanrafael.com.ar',
        'SOLTERO',
        'EMPLEADO',
        1,
        'A',
        '123'
    ),
    (
        'Martin',
        'Ruiz',
        'mruiz',
        '30999000',
        'M',
        36,
        'Chile 963',
        '3815551109',
        'martin.ruiz@farmaciasanrafael.com.ar',
        'CASADO',
        'EMPLEADO',
        6,
        'A',
        '123'
    ),
    (
        'Sofia',
        'Herrera',
        'sherrera',
        '31000111',
        'F',
        33,
        'Peru 159',
        '3815551110',
        'sofia.herrera@farmaciasanrafael.com.ar',
        'SOLTERO',
        'EMPLEADO',
        4,
        'A',
        '123'
    ),
    (
        'Tomas',
        'Acosta',
        'tacosta',
        '31111222',
        'M',
        28,
        'Maipu 753',
        '3815551111',
        'tomas.acosta@farmaciasanrafael.com.ar',
        'SOLTERO',
        'EMPLEADO',
        2,
        'A',
        '123'
    ),
    (
        'Valeria',
        'Ferreyra',
        'vferreyra',
        '31222333',
        'F',
        37,
        'Catamarca 456',
        '3815551112',
        'valeria.ferreyra@farmaciasanrafael.com.ar',
        'CASADO',
        'EMPLEADO',
        7,
        'A',
        '123'
    ),
    (
        'Nicolas',
        'Molina',
        'nmolina',
        '31333444',
        'M',
        30,
        'Cordoba 123',
        '3815551113',
        'nicolas.molina@farmaciasanrafael.com.ar',
        'SOLTERO',
        'EMPLEADO',
        3,
        'A',
        '123'
    ),
    (
        'Julieta',
        'Castro',
        'jcastro',
        '31444555',
        'F',
        25,
        'Buenos Aires 321',
        '3815551114',
        'julieta.castro@farmaciasanrafael.com.ar',
        'SOLTERO',
        'EMPLEADO',
        1,
        'A',
        '123'
    ),
    (
        'Federico',
        'Ramos',
        'framos',
        '31555666',
        'M',
        42,
        'Salta 654',
        '3815551115',
        'federico.ramos@farmaciasanrafael.com.ar',
        'CASADO',
        'EMPLEADO',
        10,
        'A',
        '123'
    ),
    (
        'Milagros',
        'Navarro',
        'mnavarro',
        '31666777',
        'F',
        24,
        '24 de Septiembre 987',
        '3815551116',
        'milagros.navarro@farmaciasanrafael.com.ar',
        'SOLTERO',
        'EMPLEADO',
        1,
        'A',
        '123'
    ),
    (
        'Gonzalo',
        'Vega',
        'gvega',
        '31777888',
        'M',
        35,
        'Alem 246',
        '3815551117',
        'gonzalo.vega@farmaciasanrafael.com.ar',
        'CASADO',
        'EMPLEADO',
        6,
        'I',
        '123'
    ),
    (
        'Camila',
        'Ortega',
        'cortega',
        '31888999',
        'F',
        29,
        'Ayacucho 135',
        '3815551118',
        'camila.ortega@farmaciasanrafael.com.ar',
        'SOLTERO',
        'EMPLEADO',
        2,
        'A',
        '123'
    ),
    (
        'Bruno',
        'Silva',
        'bsilva',
        '31999000',
        'M',
        32,
        'Lamadrid 864',
        '3815551119',
        'bruno.silva@farmaciasanrafael.com.ar',
        'CASADO',
        'EMPLEADO',
        5,
        'A',
        '123'
    ),
    (
        'Elena',
        'Paz',
        'epaz',
        '32000111',
        'F',
        41,
        'General Paz 951',
        '3815551120',
        'elena.paz@farmaciasanrafael.com.ar',
        'DIVORCIADO',
        'EMPLEADO',
        11,
        'A',
        '123'
    );

INSERT INTO
    `Proveedores` (
        `Nombre`,
        `Telefono`,
        `Mail`,
        `Direccion`,
        `Estado`
    )
VALUES (
        'Drogueria del Norte',
        '3814301001',
        'ventas@drogueriadelnorte.com.ar',
        'Ruta 9 Km 1200, Tucuman',
        'A'
    ),
    (
        'Distribuidora San Javier',
        '3814301002',
        'pedidos@sanjavierdistribuidora.com.ar',
        'Av. Independencia 100, San Miguel de Tucuman',
        'A'
    ),
    (
        'Laboratorios NOA',
        '3814301003',
        'comercial@laboratoriosnoa.com.ar',
        'Av. Roca 230, Yerba Buena',
        'A'
    ),
    (
        'FarmaLogistica SRL',
        '3814301004',
        'contacto@farmalogistica.com.ar',
        'San Lorenzo 450, Tafi Viejo',
        'A'
    ),
    (
        'Drogueria Central',
        '3814301005',
        'ventas@drogueriacentral.com.ar',
        'Crisostomo Alvarez 560, Tucuman',
        'A'
    ),
    (
        'Distribuidora Vida',
        '3814301006',
        'pedidos@distribuidoravida.com.ar',
        '9 de Julio 78, Banda del Rio Sali',
        'A'
    ),
    (
        'Nova Salud Mayorista',
        '3814301007',
        'mayorista@novasalud.com.ar',
        'Lavalle 901, Tucuman',
        'A'
    ),
    (
        'BioFarma Insumos',
        '3814301008',
        'ventas@biofarma.com.ar',
        'Rivadavia 456, Concepcion',
        'A'
    ),
    (
        'Cadena Medica',
        '3814301009',
        'pedidos@cadenamedica.com.ar',
        'Entre Rios 678, Monteros',
        'A'
    ),
    (
        'Punto Farma Proveedores',
        '3814301010',
        'contacto@puntofarma.com.ar',
        'Matheu 990, Tucuman',
        'A'
    ),
    (
        'Distribuidora Alem',
        '3814301011',
        'ventas@distribuidoraalem.com.ar',
        'Florida 123, Tucuman',
        'A'
    ),
    (
        'Salud Integral SRL',
        '3814301012',
        'pedidos@saludintegralsrl.com.ar',
        'Junin 753, Tucuman',
        'A'
    ),
    (
        'Drogueria del Parque',
        '3814301013',
        'contacto@drogueriadelparque.com.ar',
        'Santiago 951, Yerba Buena',
        'A'
    ),
    (
        'FarmaExpress',
        '3814301014',
        'ventas@farmaexpress.com.ar',
        'Balcarce 258, Tucuman',
        'A'
    ),
    (
        'MediSur Distribuciones',
        '3814301015',
        'pedidos@medisur.com.ar',
        'Las Heras 147, Aguilares',
        'A'
    ),
    (
        'Andes Pharma',
        '3814301016',
        'comercial@andespharma.com.ar',
        'Corrientes 321, Tucuman',
        'A'
    ),
    (
        'Drogueria Independencia',
        '3814301017',
        'ventas@drogueriaindependencia.com.ar',
        'Bolivar 159, Tucuman',
        'A'
    ),
    (
        'FarmaUnion',
        '3814301018',
        'pedidos@farmaunion.com.ar',
        'Pellegrini 753, Tucuman',
        'A'
    ),
    (
        'Distribuidora del Valle',
        '3814301019',
        'contacto@distribuidoradelvalle.com.ar',
        'Necochea 852, Famailla',
        'I'
    ),
    (
        'Red Farma Mayorista',
        '3814301020',
        'ventas@redfarma.com.ar',
        'Marcos Paz 654, Tucuman',
        'A'
    );

INSERT INTO
    `Monodrogas` (`Nombre`, `Estado`)
VALUES ('Paracetamol', 'A'),
    ('Ibuprofeno', 'A'),
    ('Amoxicilina', 'A'),
    ('Omeprazol', 'A'),
    ('Loratadina', 'A'),
    ('Diclofenac', 'A'),
    ('Aspirina', 'A'),
    ('Metformina', 'A'),
    ('Salbutamol', 'A'),
    ('Azitromicina', 'A'),
    ('Cafeina', 'A'),
    ('Vitamina C', 'A'),
    ('Cetirizina', 'A'),
    ('Ranitidina', 'I'),
    ('Clonazepam', 'A'),
    ('Miconazol', 'A'),
    ('Budesonida', 'A'),
    ('Fenilefrina', 'A'),
    ('Dextrometorfano', 'A'),
    ('Ambroxol', 'A');

INSERT INTO
    `Productos` (
        `Nombre`,
        `CodigoProducto`,
        `CodigoBarra`,
        `PrecioBase`,
        `RequiereReceta`,
        `StockMinimo`,
        `Estado`
    )
VALUES (
        'Paracetamol 500 mg x 20 comprimidos',
        'P001',
        '7790000000011',
        1500.00,
        'N',
        10,
        'A'
    ),
    (
        'Ibuprofeno 400 mg x 20 comprimidos',
        'P002',
        '7790000000028',
        1800.00,
        'N',
        10,
        'A'
    ),
    (
        'Amoxicilina 500 mg x 16 capsulas',
        'P003',
        '7790000000035',
        2500.00,
        'S',
        8,
        'A'
    ),
    (
        'Omeprazol 20 mg x 14 capsulas',
        'P004',
        '7790000000042',
        2000.00,
        'N',
        6,
        'A'
    ),
    (
        'Loratadina 10 mg x 10 comprimidos',
        'P005',
        '7790000000059',
        1700.00,
        'N',
        8,
        'A'
    ),
    (
        'Antigripal Compuesto x 12 comprimidos',
        'P006',
        '7790000000066',
        2200.00,
        'N',
        12,
        'A'
    ),
    (
        'Crema Antimicotica 20 g',
        'P007',
        '7790000000073',
        2900.00,
        'N',
        5,
        'A'
    ),
    (
        'Aspirina 100 mg x 30 comprimidos',
        'P008',
        '7790000000080',
        1600.00,
        'N',
        10,
        'A'
    ),
    (
        'Metformina 850 mg x 30 comprimidos',
        'P009',
        '7790000000097',
        3100.00,
        'S',
        7,
        'A'
    ),
    (
        'Salbutamol Inhalador 200 dosis',
        'P010',
        '7790000000103',
        4500.00,
        'S',
        4,
        'A'
    ),
    (
        'Azitromicina 500 mg x 3 comprimidos',
        'P011',
        '7790000000110',
        2700.00,
        'S',
        5,
        'A'
    ),
    (
        'Jarabe para la Tos 120 ml',
        'P012',
        '7790000000127',
        2300.00,
        'N',
        6,
        'A'
    ),
    (
        'Vitamina C 1 g x 10 comprimidos',
        'P013',
        '7790000000134',
        1400.00,
        'N',
        8,
        'A'
    ),
    (
        'Cetirizina 10 mg x 10 comprimidos',
        'P014',
        '7790000000141',
        1750.00,
        'N',
        8,
        'A'
    ),
    (
        'Clonazepam 2 mg x 30 comprimidos',
        'P015',
        '7790000000158',
        3600.00,
        'S',
        3,
        'A'
    ),
    (
        'Budesonida Spray Nasal 120 dosis',
        'P016',
        '7790000000165',
        3900.00,
        'S',
        4,
        'A'
    ),
    (
        'Agua Oxigenada 10 Vol 100 ml',
        'P017',
        '7790000000172',
        950.00,
        'N',
        10,
        'A'
    ),
    (
        'Shampoo Anticaspa 250 ml',
        'P018',
        '7790000000189',
        3000.00,
        'N',
        6,
        'A'
    ),
    (
        'Alcohol Etilico 70% 500 ml',
        'P019',
        '7790000000196',
        1200.00,
        'N',
        15,
        'A'
    ),
    (
        'Gasas Esteriles x 10 unidades',
        'P020',
        '7790000000202',
        900.00,
        'N',
        20,
        'A'
    );

INSERT INTO
    `ProductoMonodrogas` (`IdProducto`, `IdMonodroga`)
VALUES (1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5),
    (6, 1),
    (6, 12),
    (6, 18),
    (7, 16),
    (8, 7),
    (9, 8),
    (10, 9),
    (11, 10),
    (12, 19),
    (12, 20),
    (13, 12),
    (14, 13),
    (15, 15),
    (16, 17);

INSERT INTO
    `ProveedorProductos` (`IdProveedor`, `IdProducto`)
VALUES (1, 1),
    (1, 2),
    (1, 6),
    (2, 3),
    (2, 11),
    (3, 4),
    (3, 14),
    (4, 5),
    (4, 13),
    (5, 7),
    (5, 18),
    (6, 8),
    (6, 19),
    (7, 9),
    (7, 15),
    (8, 10),
    (8, 16),
    (9, 12),
    (9, 20),
    (10, 17),
    (10, 18),
    (11, 1),
    (11, 13),
    (12, 2),
    (12, 19),
    (13, 3),
    (13, 10),
    (14, 4),
    (14, 20),
    (15, 5),
    (15, 17),
    (16, 6),
    (16, 12),
    (17, 7),
    (17, 18),
    (18, 8),
    (18, 19),
    (19, 9),
    (19, 14),
    (20, 10),
    (20, 16);

INSERT INTO
    `Ventas` (
        `IdVenta`,
        `IdUsuario`,
        `FechaVenta`,
        `Estado`
    )
VALUES (
        1,
        1,
        '2026-01-01 10:00:00',
        'A'
    ),
    (
        2,
        2,
        '2026-01-02 10:00:00',
        'A'
    ),
    (
        3,
        3,
        '2026-01-03 10:00:00',
        'A'
    ),
    (
        4,
        4,
        '2026-01-04 10:00:00',
        'A'
    ),
    (
        5,
        5,
        '2026-01-05 10:00:00',
        'A'
    ),
    (
        6,
        6,
        '2026-01-06 10:00:00',
        'A'
    ),
    (
        7,
        7,
        '2026-01-07 10:00:00',
        'A'
    ),
    (
        8,
        8,
        '2026-01-08 10:00:00',
        'A'
    ),
    (
        9,
        9,
        '2026-01-09 10:00:00',
        'A'
    ),
    (
        10,
        10,
        '2026-01-10 10:00:00',
        'A'
    ),
    (
        11,
        11,
        '2026-01-11 10:00:00',
        'A'
    ),
    (
        12,
        12,
        '2026-01-12 10:00:00',
        'A'
    ),
    (
        13,
        13,
        '2026-01-13 10:00:00',
        'A'
    ),
    (
        14,
        14,
        '2026-01-14 10:00:00',
        'A'
    ),
    (
        15,
        15,
        '2026-01-15 10:00:00',
        'A'
    ),
    (
        16,
        16,
        '2026-01-16 10:00:00',
        'A'
    ),
    (
        17,
        18,
        '2026-01-17 10:00:00',
        'A'
    ),
    (
        18,
        19,
        '2026-01-18 10:00:00',
        'A'
    ),
    (
        19,
        20,
        '2026-01-19 10:00:00',
        'A'
    ),
    (
        20,
        3,
        '2026-01-20 10:00:00',
        'A'
    );

INSERT INTO
    `LineaVentas` (
        `IdLineaVenta`,
        `IdVenta`,
        `IdProducto`,
        `IdUsuario`,
        `Cantidad`,
        `FechaVencimiento`,
        `Lote`,
        `FechaTransaccion`,
        `PrecioUnitario`
    )
SELECT `Ventas`.`IdVenta` * 10 + `Numeros`.`N`, 
		`Ventas`.`IdVenta`, (
        (
            `Ventas`.`IdVenta` + `Numeros`.`N` - 1
        ) % 20
    ) + 1,
    `Ventas`.`IdUsuario`,
    (`Numeros`.`N` % 5) + 1, DATE_ADD(
        '2026-06-01', INTERVAL `Ventas`.`IdVenta` DAY
    ), CONCAT(
        'LV', `Ventas`.`IdVenta`, `Numeros`.`N`
    ), DATE_ADD(
        `Ventas`.`FechaVenta`, INTERVAL `Numeros`.`N` HOUR
    ), 1000 + (
        (
            `Ventas`.`IdVenta` * 37 + `Numeros`.`N` * 53
        ) % 2500
    )
FROM `Ventas`
    JOIN (
        SELECT 1 AS `N`
        UNION ALL
        SELECT 2
        UNION ALL
        SELECT 3
    ) AS `Numeros`;

INSERT INTO
    `Compras` (
        `IdCompra`,
        `IdUsuario`,
        `IdProveedor`,
        `FechaCompra`,
        `Estado`
    )
VALUES (
        1,
        1,
        1,
        '2026-03-01 08:00:00',
        'A'
    ),
    (
        2,
        2,
        2,
        '2026-03-02 08:00:00',
        'A'
    ),
    (
        3,
        3,
        3,
        '2026-03-03 08:00:00',
        'A'
    ),
    (
        4,
        4,
        4,
        '2026-03-04 08:00:00',
        'A'
    ),
    (
        5,
        5,
        5,
        '2026-03-05 08:00:00',
        'A'
    ),
    (
        6,
        6,
        6,
        '2026-03-06 08:00:00',
        'A'
    ),
    (
        7,
        7,
        7,
        '2026-03-07 08:00:00',
        'A'
    ),
    (
        8,
        8,
        8,
        '2026-03-08 08:00:00',
        'A'
    ),
    (
        9,
        9,
        9,
        '2026-03-09 08:00:00',
        'A'
    ),
    (
        10,
        10,
        10,
        '2026-03-10 08:00:00',
        'A'
    ),
    (
        11,
        11,
        11,
        '2026-03-11 08:00:00',
        'A'
    ),
    (
        12,
        12,
        12,
        '2026-03-12 08:00:00',
        'A'
    ),
    (
        13,
        13,
        13,
        '2026-03-13 08:00:00',
        'A'
    ),
    (
        14,
        14,
        14,
        '2026-03-14 08:00:00',
        'A'
    ),
    (
        15,
        15,
        15,
        '2026-03-15 08:00:00',
        'A'
    ),
    (
        16,
        16,
        16,
        '2026-03-16 08:00:00',
        'A'
    ),
    (
        17,
        18,
        17,
        '2026-03-17 08:00:00',
        'A'
    ),
    (
        18,
        19,
        18,
        '2026-03-18 08:00:00',
        'A'
    ),
    (
        19,
        20,
        19,
        '2026-03-19 08:00:00',
        'A'
    ),
    (
        20,
        1,
        20,
        '2026-03-20 08:00:00',
        'A'
    );

INSERT INTO
    `LineaCompras` (
        `IdLineaCompra`,
        `IdCompra`,
        `IdProducto`,
        `IdUsuario`,
        `IdProveedor`,
        `PrecioCompraUnitario`,
        `FechaTransaccion`,
        `FechaVencimiento`,
        `Lote`,
        `Cantidad`
    )
SELECT `Compras`.`IdCompra` * 10 + `Numeros`.`N`, `Compras`.`IdCompra`, (
        (
            `Compras`.`IdCompra` + `Numeros`.`N` - 1
        ) % 20
    ) + 1,
    `Compras`.`IdUsuario`,
    `Compras`.`IdProveedor`,
    800 + ((
            `Compras`.`IdCompra` * 29 + `Numeros`.`N` * 17
        ) % 1800
    ), DATE_ADD(
        `Compras`.`FechaCompra`, INTERVAL `Numeros`.`N` DAY
    ), DATE_ADD(
        '2027-01-01', INTERVAL `Compras`.`IdCompra` DAY
    ), CONCAT(
        'LC', `Compras`.`IdCompra`, `Numeros`.`N`
    ), (`Numeros`.`N` % 10) + 1
FROM `Compras`
    JOIN (
        SELECT 1 AS `N`
        UNION ALL
        SELECT 2
        UNION ALL
        SELECT 3
    ) AS `Numeros`;
